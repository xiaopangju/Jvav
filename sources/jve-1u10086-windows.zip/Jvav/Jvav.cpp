﻿#include <iostream>
using namespace std;
int main()
{
    string command, type, inputcharacter;
    cout << "Welcome to Jvav Beta!It's powered by Dr.ZhangHaoYang.Get help with help with help\n";
    main:
    cout << "Jvav>";
    cin >> command;
    if (command == "help") {
        cout << "----Jvav help------Page(1/1)---\n";
        cout << "  help [page]:Get help\n  leave:Exit Jvav\n  output:Output characters\n  input:Input characters\n";
        cout << "----Jvav help------Page(1/1)---\n";
        goto main;
    }
    else if (command == "leave") {
        return 0;
    }
    else if (command == "output") {
        cout << "Jvav>output>";
        cin >> type;
            cout << type << endl;
            goto main;
    }
    else if (command == "input") {
        cout << "Jvav>input>";
        cin >> inputcharacter;
        goto main;
    }
    else {
        cout << "Unknown command\n";
        goto main;
    }
}